﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LTwin_ChuyenBay
{
    public partial class Formdangnhap : Form
    {
        public Formdangnhap()
        {
            InitializeComponent();
        }
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;

        public bool Controlbox { get; }
        public class Controller
        {
            public string User { set; get; }
            public string Pass { set; get; }
        }
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            // thực hiện lệnh tra cứu coi có đúng không.
            string Username, Password;
            Username = gtbUser.Text;
            Password = gtbPass.Text;

            int Countnum = 0; // đếm số lượng số trong password
            int Countup = 0; // đếm số lượng chữ viết hoa trong password
            int Countlow = 0; // đếm số lượng chữ viết thường trong password
            int Countsp = 0; // đếm số lượng ký tự đặc biệt trong password

            for (int i = 0; i < Password.Length; i++)
            {
                if (Password[i] >= '0' && Password[i] <= '9') Countnum++;
                if (Password[i] >= 'a' && Password[i] <= 'z') Countlow++;
                if (Password[i] >= 'A' && Password[i] <= 'Z') Countup++;
                if (Password[i] >= '!' && Password[i] <= '/' ||
                    Password[i] >= ':' && Password[i] <= '@' ||
                    Password[i] >= '[' && Password[i] <= '`' ||
                    Password[i] >= '{' && Password[i] <= '~') Countsp++;
            }

            if (Username == "" && Password == "")
            {
                MessageBox.Show("User và pass không được trống.");
            }
            else if (Username == "")
            {
                MessageBox.Show("User không được trống");
            }
            else if (Password == "")
            {
                MessageBox.Show("Pass không được trống");
            }
            else if (Username.Length <= 8)
            {
                MessageBox.Show("Tên đăng nhập phải nhiều hơn 8 ký tự!!!");
            }
            else if (Countnum == 0)
            {
                MessageBox.Show("Mật khẩu thiếu số!");
            }
            else if (Countlow == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự thường!");
            }
            else if (Countup == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự HOA!");
            }
            else if (Countsp == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự đặc biệt!");
            }
            else
            {
                /*
                if (Username == "admin" && Password == "12345")
                {
                    MessageBox.Show("Đăng nhập thành công!");
                }
                */
                if (gtbUser.Text == "Admin1234" && gtbPass.Text == "Kk462020!")
                {
                    //this.Hide();
                    Controller obj = new Controller();
                    obj.User = "Admin1234";
                    this.Hide();
                    obj.Pass = "Kk462020!";

                    var thongbao = MessageBox.Show("Đăng nhập thành công!", "Thông báo");
                    Quanlychuyenbay f = new Quanlychuyenbay();
                    f.Show();
                    //Thongbao f = new Thongbao(obj);
                    //MessageBox.Show("Đăng nhập thành công!");

                }
                else if (gtbUser.Text == "BaoHan123" && gtbPass.Text == "BHk462002!")
                {
                    //this.Hide();
                    Controller obj = new Controller();
                    obj.User = "BaoHan123";
                    this.Hide();
                    obj.Pass = "BHk462002!";

                    var thongbao = MessageBox.Show("Đăng nhập thành công!", "Thông báo");
                    Quanlychuyenbay f = new Quanlychuyenbay();
                    f.Show();
                    //Thongbao f = new Thongbao(obj);
                    //MessageBox.Show("Đăng nhập thành công!");

                }
                else if (gtbUser.Text == "AnhKhoa123" && gtbPass.Text == "AKk462002!")
                {
                    //this.Hide();
                    Controller obj = new Controller();
                    obj.User = "AnhKhoa123";
                    this.Hide();
                    obj.Pass = "AHk462002!";

                    var thongbao = MessageBox.Show("Đăng nhập thành công!", "Thông báo");
                    Quanlychuyenbay f = new Quanlychuyenbay();
                    f.Show();
                    //Thongbao f = new Thongbao(obj);
                    //MessageBox.Show("Đăng nhập thành công!");

                }
                else if (gtbUser.Text == "NgocNhun123" && gtbPass.Text == "NNk462002!")
                {
                    //this.Hide();
                    Controller obj = new Controller();
                    obj.User = "NgocNhun123";
                    this.Hide();
                    obj.Pass = "NNk462002!";

                    var thongbao = MessageBox.Show("Đăng nhập thành công!", "Thông báo");
                    Quanlychuyenbay f = new Quanlychuyenbay();
                    f.Show();
                    //Thongbao f = new Thongbao(obj);
                    //MessageBox.Show("Đăng nhập thành công!");

                }
                else if (gtbUser.Text == "TuTrinh123" && gtbPass.Text == "TTk462002!")
                {
                    //this.Hide();
                    Controller obj = new Controller();
                    obj.User = "TuTrinh123";
                    this.Hide();
                    obj.Pass = "TTk462002!";

                    var thongbao = MessageBox.Show("Đăng nhập thành công!", "Thông báo");
                    Quanlychuyenbay f = new Quanlychuyenbay();
                    f.Show();
                    //Thongbao f = new Thongbao(obj);
                    //MessageBox.Show("Đăng nhập thành công!");

                }

                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu sai, xin vui lòng nhập lại");
                }
            }
        }

        private void Formdangnhap_Load(object sender, EventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            var thongbao = MessageBox.Show("Bạn có chắc thoát đăng nhập không!", "Thông báo", MessageBoxButtons.YesNo);
            if (thongbao == DialogResult.Yes) this.Close();
            else if (thongbao == DialogResult.No) { }
        }

        private void gtbUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
