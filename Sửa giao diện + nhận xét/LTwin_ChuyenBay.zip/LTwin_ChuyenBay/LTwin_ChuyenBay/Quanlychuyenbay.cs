﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace LTwin_ChuyenBay
{
    public partial class Quanlychuyenbay : Form
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;

        public bool Controlbox { get; }
        public class Controller
        {
            public string User { set; get; }
            public string Pass { set; get; }
        }


        public Quanlychuyenbay()
        {
            InitializeComponent();
            random = new Random();
            btnCloseChildForm.Visible = false;
            this.Text = string.Empty;
            this.Controlbox = false;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private Color SelectThemeColor() //chọn màu chủ đề 
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnSender)//nút/lệnh hoạt động 
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Times New Roman", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelTieude.BackColor = color;
                    panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    btnCloseChildForm.Visible = true;
                }
            }
        }
        private void DisableButton() //vô hiệu hóa nút/lệnh 
        {
            foreach (Control previousBtn in panelMenu.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 76);
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktopPane.Controls.Add(childForm);
            this.panelDesktopPane.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTieude.Text = childForm.Text;
        }

        private void Quanlychuyenbay_Load(object sender, EventArgs e)
        {

        }

        private void btnDatve_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormKTve(), sender);
        }

        private void btnChuyenbay_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormDSChuyenbay(), sender);
        }

        private void btnPhannan_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormDatVe(), sender);
        }

        private void btnQuanly_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormQuanly(), sender);
        }

        private void btnGioithieu_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormGioithieu(), sender);
        }

        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            Reset();
        }
        private void Reset()
        {
            DisableButton();
            lblTieude.Text = "Chào mừng bạn đến với hãng hàng không WinX";
            panelTieude.BackColor = Color.FromArgb(0,150,136);  //thay đổi theo đặc màu
            panelLogo.BackColor = Color.FromArgb(39, 39, 58);   //thay đổi theo đặc màu
            currentButton = null;
            btnCloseChildForm.Visible = false;
        }

        private void panelTieude_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        /*private void btCancel_Click(object sender, EventArgs e)
        {
            DialogResult rep;
            rep = MessageBox.Show("Bạn chắc chắn muốn thoát?", "Trả lời", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (rep == DialogResult.OK)
            {
                Application.Exit();
            }

        }*/

        /*private void tbUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbPass_TextChanged(object sender, EventArgs e)
        {

        }

       /* private void btLogin_Click(object sender, EventArgs e)
        {
            // thực hiện lệnh tra cứu coi có đúng không.
            string Username, Password;
            Username = tbUser.Text;
            Password = tbPass.Text;

            int Countnum = 0; // đếm số lượng số trong password
            int Countup = 0; // đếm số lượng chữ viết hoa trong password
            int Countlow = 0; // đếm số lượng chữ viết thường trong password
            int Countsp = 0; // đếm số lượng ký tự đặc biệt trong password

            for (int i = 0; i < Password.Length; i++)
            {
                if (Password[i] >= '0' && Password[i] <= '9') Countnum++;
                if (Password[i] >= 'a' && Password[i] <= 'z') Countlow++;
                if (Password[i] >= 'A' && Password[i] <= 'Z') Countup++;
                if (Password[i] >= '!' && Password[i] <= '/' ||
                    Password[i] >= ':' && Password[i] <= '@' ||
                    Password[i] >= '[' && Password[i] <= '`' ||
                    Password[i] >= '{' && Password[i] <= '~') Countsp++;
            }

            if (Username == "" && Password == "")
            {
                MessageBox.Show("User và pass không được trống.");
            }
            else if (Username == "")
            {
                MessageBox.Show("User không được trống");
            }
            else if (Password == "")
            {
                MessageBox.Show("Pass không được trống");
            }
            else if (Username.Length <= 8)
            {
                MessageBox.Show("Tên đăng nhập phải nhiều hơn 8 ký tự!!!");
            }
            else if (Countnum == 0)
            {
                MessageBox.Show("Mật khẩu thiếu số!");
            }
            else if (Countlow == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự thường!");
            }
            else if (Countup == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự HOA!");
            }
            else if (Countsp == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự đặc biệt!");
            }
            else
            {
                /*
                if (Username == "admin" && Password == "12345")
                {
                    MessageBox.Show("Đăng nhập thành công!");
                }
                
                if (tbUser.Text == "TuanKiet1" && tbPass.Text == "Kk462020!")
                {
                    //this.Hide();
                    Controller obj = new Controller();
                    obj.User = "TuanKiet1";
                    this.Hide();
                    obj.Pass = "Kk462020!";

                    MessageBox.Show("Đăng nhập thành công!");
                    Quanlychuyenbay f = new Quanlychuyenbay();
                    f.Show();
                    //Thongbao f = new Thongbao(obj);
                    //MessageBox.Show("Đăng nhập thành công!");
                  
                }

                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu sai, xin vui lòng nhập lại");
                }
            }

        }*/

        private void panelDesktopPane_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelTieude_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
