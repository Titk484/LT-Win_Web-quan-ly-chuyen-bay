﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LTwin_ChuyenBay
{
    public partial class ve1 : Form
    {
        public ve1()
        {
            InitializeComponent();
        }
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-VDLUHCU\SQLEXPRESS;Initial Catalog=QLCB17;Integrated Security=True
";

        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loadData1() //Ve
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from Ve";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }
       
       
        private void btReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ve1_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData1();
        }

     
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            tbMCB.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            tbMV.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            tbMKH.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            dtDI1.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            dtDEN1.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
            tbSB1.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
            tbSBden1.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
            tbGhe1.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();
            tbGV1.Text = dataGridView1.Rows[i].Cells[8].Value.ToString();
        }

        
        private void btThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "insert into Ve values('" + tbMCB.Text + "','" + tbMV.Text + "','" + tbMKH.Text + "','" + dtDI1.Text + "','" + dtDEN1.Text + "','" + tbSB1.Text + "','" + tbSBden1.Text + "','" + tbGhe1.Text + "','" + tbGV1.Text + "')";
            command.ExecuteNonQuery();
            loadData1();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from Ve where MAVE = '" + tbMV.Text + "'";
            command.ExecuteNonQuery();
            loadData1();
        }
        /*private void btOK_Click(object sender, EventArgs e)
        {
            LinQDataContext db = new LinQDataContext();
            dataGridView1.DataSource = db.Ves.Select(q => q);
        }*/

        private void btSua_Click(object sender, EventArgs e)
        {
            /*
            //tbMV.ReadOnly = true;
            command = connection.CreateCommand();
            command.CommandText = "update Ve set MACB = '" + tbMCB.Text + "',MAKH = '" + tbMKH.Text + "',NGAYDI = '" + dtDI1.Text + "',NGAYDEN = '" + dtDEN1.Text + "',SBDI = '" + tbSB1.Text + "',SBDEN ='"+ tbSBden1 +"',GHE = '"+ tbGhe1.Text +"',GIAVE ='"+tbGV1.Text+"' where MAVE = '" + tbMV.Text + "'";
            command.ExecuteNonQuery();
            loadData1();*/
            using (LinQDataContext db = new LinQDataContext())
            {
                string macb = dataGridView1.SelectedCells[0].OwningRow.Cells["MACB"].Value.ToString();
                string mave = dataGridView1.SelectedCells[0].OwningRow.Cells["MAVE"].Value.ToString();
                string makh = dataGridView1.SelectedCells[0].OwningRow.Cells["MAKH"].Value.ToString();
                DateTime ngaydi = (DateTime)dataGridView1.SelectedCells[0].OwningRow.Cells["NGAYDI"].Value;
                DateTime ngayden = (DateTime)dataGridView1.SelectedCells[0].OwningRow.Cells["NGAYDEN"].Value;
                string sbdi = dataGridView1.SelectedCells[0].OwningRow.Cells["SBDI"].Value.ToString();
                string sbden = dataGridView1.SelectedCells[0].OwningRow.Cells["SBDEN"].Value.ToString();
                string ghe = dataGridView1.SelectedCells[0].OwningRow.Cells["GHE"].Value.ToString();
                float giave = float.Parse(dataGridView1.SelectedCells[0].OwningRow.Cells["GIAVE"].Value.ToString());

                Ve edit = db.Ves.Where(p => p.MAVE.Equals(mave)).SingleOrDefault();

                edit.MACB = macb;
                edit.MAVE = mave;
                edit.MAKH = makh;
                edit.NGAYDI = ngaydi;
                edit.NGAYDEN = ngayden;
                edit.SBDI = sbdi;
                edit.SBDEN = sbden;
                edit.GHE = ghe;
                edit.GIAVE = giave;


                db.SubmitChanges();

            }
            connection = new SqlConnection(str);
            connection.Open();
            loadData1();

        }

        
    }
}
