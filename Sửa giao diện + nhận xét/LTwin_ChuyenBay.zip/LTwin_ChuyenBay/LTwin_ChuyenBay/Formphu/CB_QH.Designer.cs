﻿namespace LTwin_ChuyenBay
{
    partial class CB_QH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CB_QH));
            this.btChon = new System.Windows.Forms.Button();
            this.btDat = new System.Windows.Forms.Button();
            this.btHuy = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btChon
            // 
            this.btChon.BackColor = System.Drawing.Color.SkyBlue;
            this.btChon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btChon.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btChon.Location = new System.Drawing.Point(416, 558);
            this.btChon.Name = "btChon";
            this.btChon.Size = new System.Drawing.Size(66, 40);
            this.btChon.TabIndex = 19;
            this.btChon.Text = "Chọn";
            this.btChon.UseVisualStyleBackColor = false;
            this.btChon.Click += new System.EventHandler(this.btChon_Click);
            // 
            // btDat
            // 
            this.btDat.BackColor = System.Drawing.Color.SkyBlue;
            this.btDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDat.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDat.Location = new System.Drawing.Point(595, 558);
            this.btDat.Name = "btDat";
            this.btDat.Size = new System.Drawing.Size(66, 40);
            this.btDat.TabIndex = 17;
            this.btDat.Text = "Đặt";
            this.btDat.UseVisualStyleBackColor = false;
            this.btDat.Click += new System.EventHandler(this.btDat_Click);
            // 
            // btHuy
            // 
            this.btHuy.BackColor = System.Drawing.Color.SkyBlue;
            this.btHuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy.Location = new System.Drawing.Point(509, 558);
            this.btHuy.Name = "btHuy";
            this.btHuy.Size = new System.Drawing.Size(66, 40);
            this.btHuy.TabIndex = 18;
            this.btHuy.Text = "Hủy";
            this.btHuy.UseVisualStyleBackColor = false;
            this.btHuy.Click += new System.EventHandler(this.btHuy_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(159, 569);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(168, 25);
            this.textBox1.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 570);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "Thành tiền";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.button57);
            this.panel1.Controls.Add(this.button58);
            this.panel1.Controls.Add(this.button59);
            this.panel1.Controls.Add(this.button60);
            this.panel1.Controls.Add(this.button61);
            this.panel1.Controls.Add(this.button62);
            this.panel1.Controls.Add(this.button63);
            this.panel1.Controls.Add(this.button64);
            this.panel1.Controls.Add(this.button65);
            this.panel1.Controls.Add(this.button66);
            this.panel1.Controls.Add(this.button67);
            this.panel1.Controls.Add(this.button68);
            this.panel1.Controls.Add(this.button69);
            this.panel1.Controls.Add(this.button70);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button35);
            this.panel1.Controls.Add(this.button42);
            this.panel1.Controls.Add(this.button49);
            this.panel1.Controls.Add(this.button50);
            this.panel1.Controls.Add(this.button51);
            this.panel1.Controls.Add(this.button52);
            this.panel1.Controls.Add(this.button53);
            this.panel1.Controls.Add(this.button54);
            this.panel1.Controls.Add(this.button55);
            this.panel1.Controls.Add(this.button56);
            this.panel1.Controls.Add(this.button48);
            this.panel1.Controls.Add(this.button41);
            this.panel1.Controls.Add(this.button34);
            this.panel1.Controls.Add(this.button27);
            this.panel1.Controls.Add(this.button20);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button47);
            this.panel1.Controls.Add(this.button40);
            this.panel1.Controls.Add(this.button33);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.button19);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Location = new System.Drawing.Point(70, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 498);
            this.panel1.TabIndex = 14;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(103, 428);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(66, 40);
            this.button57.TabIndex = 15;
            this.button57.Text = "7B";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(103, 361);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(66, 40);
            this.button58.TabIndex = 16;
            this.button58.Text = "6B";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(103, 291);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(66, 40);
            this.button59.TabIndex = 17;
            this.button59.Text = "5B";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(103, 220);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(66, 40);
            this.button60.TabIndex = 18;
            this.button60.Text = "4B";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(103, 154);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(66, 40);
            this.button61.TabIndex = 19;
            this.button61.Text = "3B";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(103, 85);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(66, 40);
            this.button62.TabIndex = 20;
            this.button62.Text = "2B";
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(103, 18);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(66, 40);
            this.button63.TabIndex = 21;
            this.button63.Text = "1B";
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(17, 428);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(66, 40);
            this.button64.TabIndex = 22;
            this.button64.Text = "7A";
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(17, 361);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(66, 40);
            this.button65.TabIndex = 23;
            this.button65.Text = "6A";
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(17, 291);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(66, 40);
            this.button66.TabIndex = 24;
            this.button66.Text = "5A";
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(17, 220);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(66, 40);
            this.button67.TabIndex = 25;
            this.button67.Text = "4A";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(17, 153);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(66, 40);
            this.button68.TabIndex = 26;
            this.button68.Text = "3A";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(17, 84);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(66, 40);
            this.button69.TabIndex = 27;
            this.button69.Text = "2A";
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(17, 17);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(66, 40);
            this.button70.TabIndex = 28;
            this.button70.Text = "1A";
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(346, 429);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(66, 40);
            this.button7.TabIndex = 1;
            this.button7.Text = "7D";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(346, 362);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(66, 40);
            this.button14.TabIndex = 2;
            this.button14.Text = "6D";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(346, 292);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(66, 40);
            this.button21.TabIndex = 3;
            this.button21.Text = "5D";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(346, 221);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(66, 40);
            this.button28.TabIndex = 4;
            this.button28.Text = "4D";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(346, 155);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(66, 40);
            this.button35.TabIndex = 5;
            this.button35.Text = "3D";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(346, 86);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(66, 40);
            this.button42.TabIndex = 6;
            this.button42.Text = "2D";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(346, 19);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(66, 40);
            this.button49.TabIndex = 7;
            this.button49.Text = "1D";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(191, 429);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(66, 40);
            this.button50.TabIndex = 8;
            this.button50.Text = "7C";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(191, 362);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(66, 40);
            this.button51.TabIndex = 9;
            this.button51.Text = "6C";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(191, 292);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(66, 40);
            this.button52.TabIndex = 10;
            this.button52.Text = "5C";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(191, 221);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(66, 40);
            this.button53.TabIndex = 11;
            this.button53.Text = "4C";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(191, 154);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(66, 40);
            this.button54.TabIndex = 12;
            this.button54.Text = "3C";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(191, 85);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(66, 40);
            this.button55.TabIndex = 13;
            this.button55.Text = "2C";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(191, 18);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(66, 40);
            this.button56.TabIndex = 14;
            this.button56.Text = "1C";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(525, 429);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(66, 40);
            this.button48.TabIndex = 0;
            this.button48.Text = "7F";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(525, 362);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(66, 40);
            this.button41.TabIndex = 0;
            this.button41.Text = "6F";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(525, 292);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(66, 40);
            this.button34.TabIndex = 0;
            this.button34.Text = "5F";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(525, 221);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(66, 40);
            this.button27.TabIndex = 0;
            this.button27.Text = "4F";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(525, 155);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(66, 40);
            this.button20.TabIndex = 0;
            this.button20.Text = "3F";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(525, 86);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(66, 40);
            this.button13.TabIndex = 0;
            this.button13.Text = "2F";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(525, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(66, 40);
            this.button6.TabIndex = 0;
            this.button6.Text = "1F";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(439, 429);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(66, 40);
            this.button47.TabIndex = 0;
            this.button47.Text = "7E";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(439, 362);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(66, 40);
            this.button40.TabIndex = 0;
            this.button40.Text = "6E";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(439, 292);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(66, 40);
            this.button33.TabIndex = 0;
            this.button33.Text = "5E";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(439, 221);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(66, 40);
            this.button26.TabIndex = 0;
            this.button26.Text = "4E";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(439, 154);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(66, 40);
            this.button19.TabIndex = 0;
            this.button19.Text = "3E";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(439, 85);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(66, 40);
            this.button12.TabIndex = 0;
            this.button12.Text = "2E";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(439, 18);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(66, 40);
            this.button5.TabIndex = 0;
            this.button5.Text = "1E";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1225, 405);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 17);
            this.label3.TabIndex = 26;
            this.label3.Text = "Chú thích";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::LTwin_ChuyenBay.Properties.Resources.Screenshot_2021_12_25_140924;
            this.pictureBox2.Location = new System.Drawing.Point(1122, 436);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(278, 162);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LTwin_ChuyenBay.Properties.Resources._7BA6E7CD_709F_4595_A843_6A5131F8BF2E1;
            this.pictureBox1.Location = new System.Drawing.Point(1099, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(307, 380);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(304, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 19);
            this.label1.TabIndex = 27;
            this.label1.Text = "CHỌN GHẾ NGỒI";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.btChon);
            this.groupBox1.Controls.Add(this.btDat);
            this.groupBox1.Controls.Add(this.btHuy);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1412, 621);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            // 
            // CB_QH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1412, 622);
            this.Controls.Add(this.groupBox1);
            this.Name = "CB_QH";
            this.Text = "CB_QH";
            this.Load += new System.EventHandler(this.CB_QH_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btChon;
        private System.Windows.Forms.Button btDat;
        private System.Windows.Forms.Button btHuy;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}