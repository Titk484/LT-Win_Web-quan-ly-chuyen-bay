﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LTwin_ChuyenBay
{
    public partial class CB_VN : Form
    {
        List<Button> DSChon = new List<Button>();
        List<Button> DSDChon = new List<Button>();
        int thanhtien = 0;

        private string phepToan;
        public CB_VN()
        {
            InitializeComponent();
            textBox1.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        private void CB_VN_Load(object sender, EventArgs e)
        {

        }

        private void btDat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn đã đặt vé thành công!");
            this.Close();
        }

        private void button70_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button63_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
           
            btn.BackColor = Color.Red;
            DSDChon.Add(btn);
          
            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button56_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button49_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button69_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button62_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button55_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button42_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button68_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button61_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button54_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button35_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button67_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button60_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button53_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button28_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button26_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button27_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button66_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button59_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button52_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button33_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button34_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button65_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button58_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button51_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button40_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button41_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button64_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button57_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button50_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            btn.BackColor = Color.Red;
            DSDChon.Add(btn);

            MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button47_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void button48_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.BackColor != Color.Yellow)
            {
                if (btn.BackColor != Color.White)
                {
                    btn.BackColor = Color.Blue;
                    DSChon.Add(btn);
                }
                else
                {
                    btn.BackColor = Color.White;
                    DSChon.Remove(btn);
                }
            }
            else MessageBox.Show("Ghế đã chọn, mời bạn chọn lại!");
        }

        private void btChon_Click(object sender, EventArgs e)
        {
            foreach (Button b in DSChon)
            {
                string a = b.Text;
                if (a == "1A" || a == "1B" || a == "1C" || a == "1D" || a == "1E" || a == "1F" || a == "2A" || a == "2B" || a == "2C" || a == "2D" || a == "2E" || a == "2F")
                {

                    b.BackColor = Color.Yellow;

                    thanhtien += 200000;
                    //MessageBox.Show("Day la hang thuong gia");
                }
                else if (a == "3A" || a == "3B" || a == "3C" || a == "3D" || a == "3E" || a == "3F" || a == "4A" || a == "4B" || a == "4C" || a == "4D" || a == "4E" || a == "4F" || a == "5A" || a == "5B" || a == "5C" || a == "5D" || a == "5E" || a == "5F" || a == "6A" || a == "6B" || a == "6C" || a == "6D" || a == "6E" || a == "6F" || a == "7A" || a == "7B" || a == "7C" || a == "7D" || a == "7E" || a == "7F")
                {
                    b.BackColor = Color.Yellow;
                    thanhtien += 100000;
                }
            }
            textBox1.Text = thanhtien.ToString();
            //thanhtien = 0;
            DSChon = new List<Button>();
        }

        private void btHuy_Click(object sender, EventArgs e)
        {
            foreach(Button b in DSChon)
            {
                b.BackColor = Color.White;
            }
            textBox1.Text = "";
            DSChon = new List<Button>();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
