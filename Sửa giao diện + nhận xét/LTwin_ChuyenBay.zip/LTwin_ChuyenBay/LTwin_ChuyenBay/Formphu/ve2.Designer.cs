﻿namespace LTwin_ChuyenBay
{
    partial class ve2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ve2));
            this.btSua = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.btThem = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbSB2 = new System.Windows.Forms.TextBox();
            this.tbGV1 = new System.Windows.Forms.TextBox();
            this.tbGhe1 = new System.Windows.Forms.TextBox();
            this.tbTT = new System.Windows.Forms.TextBox();
            this.dtDI1 = new System.Windows.Forms.DateTimePicker();
            this.tbSBden1 = new System.Windows.Forms.TextBox();
            this.tbKM = new System.Windows.Forms.TextBox();
            this.dtDEN1 = new System.Windows.Forms.DateTimePicker();
            this.tbSB1 = new System.Windows.Forms.TextBox();
            this.tbGhe2 = new System.Windows.Forms.TextBox();
            this.tbMKH = new System.Windows.Forms.TextBox();
            this.tbMV = new System.Windows.Forms.TextBox();
            this.tbDen2 = new System.Windows.Forms.TextBox();
            this.tbMCB = new System.Windows.Forms.TextBox();
            this.dtDen2 = new System.Windows.Forms.DateTimePicker();
            this.lb9 = new System.Windows.Forms.Label();
            this.lb8 = new System.Windows.Forms.Label();
            this.dtDi2 = new System.Windows.Forms.DateTimePicker();
            this.lb7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lb4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb6 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lb3 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btReturn = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btSua
            // 
            this.btSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btSua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSua.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSua.Image = global::LTwin_ChuyenBay.Properties.Resources.edit;
            this.btSua.Location = new System.Drawing.Point(1269, 50);
            this.btSua.Name = "btSua";
            this.btSua.Size = new System.Drawing.Size(121, 55);
            this.btSua.TabIndex = 12;
            this.btSua.Text = "Sửa";
            this.btSua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btSua.UseVisualStyleBackColor = false;
            this.btSua.Click += new System.EventHandler(this.btSua_Click);
            // 
            // btXoa
            // 
            this.btXoa.BackColor = System.Drawing.Color.SkyBlue;
            this.btXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXoa.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa.Image = global::LTwin_ChuyenBay.Properties.Resources.bin;
            this.btXoa.Location = new System.Drawing.Point(1067, 141);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(121, 55);
            this.btXoa.TabIndex = 11;
            this.btXoa.Text = "Xóa";
            this.btXoa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btXoa.UseVisualStyleBackColor = false;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);
            // 
            // btThem
            // 
            this.btThem.BackColor = System.Drawing.Color.SkyBlue;
            this.btThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThem.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem.Image = global::LTwin_ChuyenBay.Properties.Resources.add;
            this.btThem.Location = new System.Drawing.Point(1067, 50);
            this.btThem.Name = "btThem";
            this.btThem.Size = new System.Drawing.Size(121, 55);
            this.btThem.TabIndex = 10;
            this.btThem.Text = "Thêm";
            this.btThem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btThem.UseVisualStyleBackColor = false;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(20, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(999, 252);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vé 2 chiều";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(18, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(960, 212);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.tbSB2);
            this.groupBox2.Controls.Add(this.tbGV1);
            this.groupBox2.Controls.Add(this.tbGhe1);
            this.groupBox2.Controls.Add(this.tbTT);
            this.groupBox2.Controls.Add(this.dtDI1);
            this.groupBox2.Controls.Add(this.tbSBden1);
            this.groupBox2.Controls.Add(this.tbKM);
            this.groupBox2.Controls.Add(this.dtDEN1);
            this.groupBox2.Controls.Add(this.tbSB1);
            this.groupBox2.Controls.Add(this.tbGhe2);
            this.groupBox2.Controls.Add(this.tbMKH);
            this.groupBox2.Controls.Add(this.tbMV);
            this.groupBox2.Controls.Add(this.tbDen2);
            this.groupBox2.Controls.Add(this.tbMCB);
            this.groupBox2.Controls.Add(this.dtDen2);
            this.groupBox2.Controls.Add(this.lb9);
            this.groupBox2.Controls.Add(this.lb8);
            this.groupBox2.Controls.Add(this.dtDi2);
            this.groupBox2.Controls.Add(this.lb7);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lb5);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.lb4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.lb6);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lb3);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.lb2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lb1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(20, 321);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1493, 203);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin vé";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // tbSB2
            // 
            this.tbSB2.Location = new System.Drawing.Point(845, 149);
            this.tbSB2.Name = "tbSB2";
            this.tbSB2.Size = new System.Drawing.Size(132, 27);
            this.tbSB2.TabIndex = 14;
            // 
            // tbGV1
            // 
            this.tbGV1.Location = new System.Drawing.Point(558, 146);
            this.tbGV1.Name = "tbGV1";
            this.tbGV1.Size = new System.Drawing.Size(147, 27);
            this.tbGV1.TabIndex = 6;
            // 
            // tbGhe1
            // 
            this.tbGhe1.Location = new System.Drawing.Point(558, 92);
            this.tbGhe1.Name = "tbGhe1";
            this.tbGhe1.Size = new System.Drawing.Size(147, 27);
            this.tbGhe1.TabIndex = 6;
            // 
            // tbTT
            // 
            this.tbTT.Location = new System.Drawing.Point(1367, 45);
            this.tbTT.Name = "tbTT";
            this.tbTT.Size = new System.Drawing.Size(111, 27);
            this.tbTT.TabIndex = 15;
            // 
            // dtDI1
            // 
            this.dtDI1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDI1.Location = new System.Drawing.Point(322, 39);
            this.dtDI1.Name = "dtDI1";
            this.dtDI1.Size = new System.Drawing.Size(112, 27);
            this.dtDI1.TabIndex = 5;
            // 
            // tbSBden1
            // 
            this.tbSBden1.Location = new System.Drawing.Point(558, 39);
            this.tbSBden1.Name = "tbSBden1";
            this.tbSBden1.Size = new System.Drawing.Size(158, 27);
            this.tbSBden1.TabIndex = 4;
            // 
            // tbKM
            // 
            this.tbKM.Location = new System.Drawing.Point(1118, 149);
            this.tbKM.Name = "tbKM";
            this.tbKM.Size = new System.Drawing.Size(84, 27);
            this.tbKM.TabIndex = 16;
            // 
            // dtDEN1
            // 
            this.dtDEN1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDEN1.Location = new System.Drawing.Point(322, 92);
            this.dtDEN1.Name = "dtDEN1";
            this.dtDEN1.Size = new System.Drawing.Size(112, 27);
            this.dtDEN1.TabIndex = 3;
            // 
            // tbSB1
            // 
            this.tbSB1.Location = new System.Drawing.Point(322, 146);
            this.tbSB1.Name = "tbSB1";
            this.tbSB1.Size = new System.Drawing.Size(137, 27);
            this.tbSB1.TabIndex = 1;
            // 
            // tbGhe2
            // 
            this.tbGhe2.Location = new System.Drawing.Point(1118, 95);
            this.tbGhe2.Name = "tbGhe2";
            this.tbGhe2.Size = new System.Drawing.Size(84, 27);
            this.tbGhe2.TabIndex = 17;
            // 
            // tbMKH
            // 
            this.tbMKH.Location = new System.Drawing.Point(77, 149);
            this.tbMKH.Name = "tbMKH";
            this.tbMKH.Size = new System.Drawing.Size(142, 27);
            this.tbMKH.TabIndex = 1;
            // 
            // tbMV
            // 
            this.tbMV.Location = new System.Drawing.Point(77, 92);
            this.tbMV.Name = "tbMV";
            this.tbMV.Size = new System.Drawing.Size(142, 27);
            this.tbMV.TabIndex = 1;
            // 
            // tbDen2
            // 
            this.tbDen2.Location = new System.Drawing.Point(1118, 42);
            this.tbDen2.Name = "tbDen2";
            this.tbDen2.Size = new System.Drawing.Size(143, 27);
            this.tbDen2.TabIndex = 18;
            // 
            // tbMCB
            // 
            this.tbMCB.Location = new System.Drawing.Point(77, 39);
            this.tbMCB.Name = "tbMCB";
            this.tbMCB.Size = new System.Drawing.Size(142, 27);
            this.tbMCB.TabIndex = 1;
            // 
            // dtDen2
            // 
            this.dtDen2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDen2.Location = new System.Drawing.Point(845, 95);
            this.dtDen2.Name = "dtDen2";
            this.dtDen2.Size = new System.Drawing.Size(111, 27);
            this.dtDen2.TabIndex = 12;
            // 
            // lb9
            // 
            this.lb9.AutoSize = true;
            this.lb9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb9.Location = new System.Drawing.Point(497, 149);
            this.lb9.Name = "lb9";
            this.lb9.Size = new System.Drawing.Size(52, 19);
            this.lb9.TabIndex = 0;
            this.lb9.Text = "Giá vé";
            this.lb9.Click += new System.EventHandler(this.lb9_Click);
            // 
            // lb8
            // 
            this.lb8.AutoSize = true;
            this.lb8.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb8.Location = new System.Drawing.Point(497, 97);
            this.lb8.Name = "lb8";
            this.lb8.Size = new System.Drawing.Size(37, 19);
            this.lb8.TabIndex = 0;
            this.lb8.Text = "Ghế";
            this.lb8.Click += new System.EventHandler(this.lb8_Click);
            // 
            // dtDi2
            // 
            this.dtDi2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDi2.Location = new System.Drawing.Point(845, 39);
            this.dtDi2.Name = "dtDi2";
            this.dtDi2.Size = new System.Drawing.Size(111, 27);
            this.dtDi2.TabIndex = 13;
            // 
            // lb7
            // 
            this.lb7.AutoSize = true;
            this.lb7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb7.Location = new System.Drawing.Point(497, 42);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(58, 19);
            this.lb7.TabIndex = 0;
            this.lb7.Text = "SB đến";
            this.lb7.Click += new System.EventHandler(this.lb7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(767, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 11;
            this.label1.Text = "Ngày đến";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lb5
            // 
            this.lb5.AutoSize = true;
            this.lb5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb5.Location = new System.Drawing.Point(248, 97);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(73, 19);
            this.lb5.TabIndex = 0;
            this.lb5.Text = "Ngày đến";
            this.lb5.Click += new System.EventHandler(this.lb5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(767, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 19);
            this.label7.TabIndex = 5;
            this.label7.Text = "Ngày đi";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // lb4
            // 
            this.lb4.AutoSize = true;
            this.lb4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb4.Location = new System.Drawing.Point(248, 42);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(62, 19);
            this.lb4.TabIndex = 0;
            this.lb4.Text = "Ngày đi";
            this.lb4.Click += new System.EventHandler(this.lb4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1283, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Thành tiền";
            // 
            // lb6
            // 
            this.lb6.AutoSize = true;
            this.lb6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb6.Location = new System.Drawing.Point(248, 149);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(47, 19);
            this.lb6.TabIndex = 0;
            this.lb6.Text = "SB đi";
            this.lb6.Click += new System.EventHandler(this.lb6_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1023, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "Ghế";
            // 
            // lb3
            // 
            this.lb3.AutoSize = true;
            this.lb3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb3.Location = new System.Drawing.Point(15, 149);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(51, 19);
            this.lb3.TabIndex = 0;
            this.lb3.Text = "Mã kh";
            this.lb3.Click += new System.EventHandler(this.lb3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1023, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "SB đến";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb2.Location = new System.Drawing.Point(14, 97);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(50, 19);
            this.lb2.TabIndex = 0;
            this.lb2.Text = "Mã vé";
            this.lb2.Click += new System.EventHandler(this.lb2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1023, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Khuyến mãi";
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1.Location = new System.Drawing.Point(15, 42);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(51, 19);
            this.lb1.TabIndex = 0;
            this.lb1.Text = "Mã cb";
            this.lb1.Click += new System.EventHandler(this.lb1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(767, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "SB đi";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // btReturn
            // 
            this.btReturn.BackColor = System.Drawing.Color.SkyBlue;
            this.btReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btReturn.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btReturn.Image = global::LTwin_ChuyenBay.Properties.Resources.back;
            this.btReturn.Location = new System.Drawing.Point(1269, 141);
            this.btReturn.Name = "btReturn";
            this.btReturn.Size = new System.Drawing.Size(121, 55);
            this.btReturn.TabIndex = 13;
            this.btReturn.Text = "Quay về";
            this.btReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btReturn.UseVisualStyleBackColor = false;
            this.btReturn.Click += new System.EventHandler(this.btReturn_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox3.BackgroundImage")));
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox3.Controls.Add(this.btReturn);
            this.groupBox3.Controls.Add(this.btSua);
            this.groupBox3.Controls.Add(this.btXoa);
            this.groupBox3.Controls.Add(this.btThem);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Location = new System.Drawing.Point(-6, 1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1608, 547);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            // 
            // ve2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1602, 551);
            this.Controls.Add(this.groupBox3);
            this.Name = "ve2";
            this.Text = "ve2";
            this.Load += new System.EventHandler(this.ve2_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btSua;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btThem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbGV1;
        private System.Windows.Forms.TextBox tbGhe1;
        private System.Windows.Forms.DateTimePicker dtDI1;
        private System.Windows.Forms.TextBox tbSBden1;
        private System.Windows.Forms.DateTimePicker dtDEN1;
        private System.Windows.Forms.TextBox tbSB1;
        private System.Windows.Forms.TextBox tbMKH;
        private System.Windows.Forms.TextBox tbMV;
        private System.Windows.Forms.TextBox tbMCB;
        private System.Windows.Forms.Label lb9;
        private System.Windows.Forms.Label lb8;
        private System.Windows.Forms.Label lb7;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Label lb4;
        private System.Windows.Forms.Label lb6;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.Button btReturn;
        private System.Windows.Forms.TextBox tbSB2;
        private System.Windows.Forms.TextBox tbTT;
        private System.Windows.Forms.TextBox tbKM;
        private System.Windows.Forms.TextBox tbGhe2;
        private System.Windows.Forms.TextBox tbDen2;
        private System.Windows.Forms.DateTimePicker dtDen2;
        private System.Windows.Forms.DateTimePicker dtDi2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}