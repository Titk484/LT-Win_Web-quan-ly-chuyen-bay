﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LTwin_ChuyenBay
{
    public partial class ve2 : Form
    {
        public ve2()
        {
            InitializeComponent();
        }
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-VDLUHCU\SQLEXPRESS;Initial Catalog=QLCB17;Integrated Security=True";

        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loadData1() //Ve
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from Ve2chieu";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void btReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ve2_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData1();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            tbMCB.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            tbMV.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            tbMKH.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            dtDI1.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            dtDEN1.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
            tbSB1.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
            tbSBden1.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
            tbGhe1.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();
            dtDi2.Text = dataGridView1.Rows[i].Cells[8].Value.ToString();
            dtDen2.Text = dataGridView1.Rows[i].Cells[9].Value.ToString();
            tbSB2.Text = dataGridView1.Rows[i].Cells[10].Value.ToString();
            tbDen2.Text = dataGridView1.Rows[i].Cells[11].Value.ToString();
            tbGhe2.Text = dataGridView1.Rows[i].Cells[12].Value.ToString();
            tbGV1.Text = dataGridView1.Rows[i].Cells[13].Value.ToString();
            tbKM.Text = dataGridView1.Rows[i].Cells[14].Value.ToString();
            tbTT.Text = dataGridView1.Rows[i].Cells[15].Value.ToString();

        }

        private void btThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "insert into Ve2chieu values('" + tbMCB.Text + "','" + tbMV.Text + "','" + tbMKH.Text + "','" + dtDI1.Text + "','" + dtDEN1.Text + "','" + tbSB1.Text + "','" + tbSBden1.Text + "','" + tbGhe1.Text + "','" + dtDi2.Text + "','" + dtDen2.Text + "','" + tbSB2.Text + "','" + tbDen2.Text + "','" + tbGhe2.Text + "','" + tbGV1.Text + "','" + tbKM.Text + "','" +tbTT.Text + "')";
            command.ExecuteNonQuery();
            loadData1();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from Ve2chieu where MAVE = '" + tbMV.Text + "'";
            command.ExecuteNonQuery();
            loadData1();
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            using (LinQDataContext db = new LinQDataContext())
            {
                string macb = dataGridView1.SelectedCells[0].OwningRow.Cells["MACB"].Value.ToString();
                string mave = dataGridView1.SelectedCells[0].OwningRow.Cells["MAVE"].Value.ToString();
                string makh = dataGridView1.SelectedCells[0].OwningRow.Cells["MAKH"].Value.ToString();
                DateTime ngaydi = (DateTime)dataGridView1.SelectedCells[0].OwningRow.Cells["NDI1"].Value;
                DateTime ngayden = (DateTime)dataGridView1.SelectedCells[0].OwningRow.Cells["NDEN1"].Value;
                string sbdi = dataGridView1.SelectedCells[0].OwningRow.Cells["SBDI1"].Value.ToString();
                string sbden = dataGridView1.SelectedCells[0].OwningRow.Cells["SBDEN1"].Value.ToString();
                string ghe = (dataGridView1.SelectedCells[0].OwningRow.Cells["GHE1"].Value.ToString());
                DateTime ngaydi2 = (DateTime)dataGridView1.SelectedCells[0].OwningRow.Cells["NDI2"].Value;
                DateTime ngayden2 = (DateTime)dataGridView1.SelectedCells[0].OwningRow.Cells["NDEN2"].Value;
                string sbdi1 = dataGridView1.SelectedCells[0].OwningRow.Cells["SBDI2"].Value.ToString();
                string sbden1 = dataGridView1.SelectedCells[0].OwningRow.Cells["SBDEN2"].Value.ToString();
                string ghe1 = (dataGridView1.SelectedCells[0].OwningRow.Cells["GHE2"].Value.ToString());
                float giave = float.Parse(dataGridView1.SelectedCells[0].OwningRow.Cells["GIAVE"].Value.ToString());
                string khuyenmai = dataGridView1.SelectedCells[0].OwningRow.Cells["KHUYENMAI"].Value.ToString();
                float thanhtien = float.Parse(dataGridView1.SelectedCells[0].OwningRow.Cells["THANHTIEN"].Value.ToString());

                Ve2Chieu edit = db.Ve2Chieus.Where(p => p.MAVE.Equals(mave)).SingleOrDefault();

                edit.MACB = macb;
                edit.MAVE = mave;
                edit.MAKH = makh;
                edit.NDI1 = ngaydi;
                edit.NDEN1 = ngayden;
                edit.SBDI1 = sbdi;
                edit.SBDEN1 = sbden;
                edit.GHE1 = ghe;
                edit.NDI2 = ngaydi2;
                edit.NDEN2 = ngayden2;
                edit.SBDI2 = sbdi1;
                edit.NDEN2 = ngayden;
                edit.GHE1 = ghe1;
                edit.GIAVE = giave;
                edit.KHUYENMAI = khuyenmai;
                edit.THANHTIEN = thanhtien;



                db.SubmitChanges();

            }
            connection = new SqlConnection(str);
            connection.Open();
            loadData1();

        }

        private void lb1_Click(object sender, EventArgs e)
        {

        }

        private void lb2_Click(object sender, EventArgs e)
        {

        }

        private void lb3_Click(object sender, EventArgs e)
        {

        }

        private void lb4_Click(object sender, EventArgs e)
        {

        }

        private void lb5_Click(object sender, EventArgs e)
        {

        }

        private void lb7_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void lb6_Click(object sender, EventArgs e)
        {

        }

        private void lb8_Click(object sender, EventArgs e)
        {

        }

        private void lb9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
