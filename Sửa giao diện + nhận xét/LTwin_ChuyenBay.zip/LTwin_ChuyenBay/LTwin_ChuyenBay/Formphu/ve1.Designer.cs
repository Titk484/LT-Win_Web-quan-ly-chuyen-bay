﻿namespace LTwin_ChuyenBay
{
    partial class ve1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ve1));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbGV1 = new System.Windows.Forms.TextBox();
            this.tbGhe1 = new System.Windows.Forms.TextBox();
            this.dtDI1 = new System.Windows.Forms.DateTimePicker();
            this.tbSBden1 = new System.Windows.Forms.TextBox();
            this.dtDEN1 = new System.Windows.Forms.DateTimePicker();
            this.tbSB1 = new System.Windows.Forms.TextBox();
            this.tbMKH = new System.Windows.Forms.TextBox();
            this.tbMV = new System.Windows.Forms.TextBox();
            this.tbMCB = new System.Windows.Forms.TextBox();
            this.lb9 = new System.Windows.Forms.Label();
            this.lb8 = new System.Windows.Forms.Label();
            this.lb7 = new System.Windows.Forms.Label();
            this.lb5 = new System.Windows.Forms.Label();
            this.lb4 = new System.Windows.Forms.Label();
            this.lb6 = new System.Windows.Forms.Label();
            this.lb3 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lb1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btReturn = new System.Windows.Forms.Button();
            this.btSua = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.btThem = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.tbGV1);
            this.groupBox2.Controls.Add(this.tbGhe1);
            this.groupBox2.Controls.Add(this.dtDI1);
            this.groupBox2.Controls.Add(this.tbSBden1);
            this.groupBox2.Controls.Add(this.dtDEN1);
            this.groupBox2.Controls.Add(this.tbSB1);
            this.groupBox2.Controls.Add(this.tbMKH);
            this.groupBox2.Controls.Add(this.tbMV);
            this.groupBox2.Controls.Add(this.tbMCB);
            this.groupBox2.Controls.Add(this.lb9);
            this.groupBox2.Controls.Add(this.lb8);
            this.groupBox2.Controls.Add(this.lb7);
            this.groupBox2.Controls.Add(this.lb5);
            this.groupBox2.Controls.Add(this.lb4);
            this.groupBox2.Controls.Add(this.lb6);
            this.groupBox2.Controls.Add(this.lb3);
            this.groupBox2.Controls.Add(this.lb2);
            this.groupBox2.Controls.Add(this.lb1);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(28, 315);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(761, 195);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin vé";
            // 
            // tbGV1
            // 
            this.tbGV1.Location = new System.Drawing.Point(576, 143);
            this.tbGV1.Name = "tbGV1";
            this.tbGV1.Size = new System.Drawing.Size(147, 25);
            this.tbGV1.TabIndex = 6;
            // 
            // tbGhe1
            // 
            this.tbGhe1.Location = new System.Drawing.Point(576, 86);
            this.tbGhe1.Name = "tbGhe1";
            this.tbGhe1.Size = new System.Drawing.Size(147, 25);
            this.tbGhe1.TabIndex = 6;
            // 
            // dtDI1
            // 
            this.dtDI1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDI1.Location = new System.Drawing.Point(337, 29);
            this.dtDI1.Name = "dtDI1";
            this.dtDI1.Size = new System.Drawing.Size(112, 25);
            this.dtDI1.TabIndex = 5;
            // 
            // tbSBden1
            // 
            this.tbSBden1.Location = new System.Drawing.Point(576, 29);
            this.tbSBden1.Name = "tbSBden1";
            this.tbSBden1.Size = new System.Drawing.Size(147, 25);
            this.tbSBden1.TabIndex = 4;
            // 
            // dtDEN1
            // 
            this.dtDEN1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDEN1.Location = new System.Drawing.Point(337, 86);
            this.dtDEN1.Name = "dtDEN1";
            this.dtDEN1.Size = new System.Drawing.Size(112, 25);
            this.dtDEN1.TabIndex = 3;
            // 
            // tbSB1
            // 
            this.tbSB1.Location = new System.Drawing.Point(337, 143);
            this.tbSB1.Name = "tbSB1";
            this.tbSB1.Size = new System.Drawing.Size(127, 25);
            this.tbSB1.TabIndex = 1;
            // 
            // tbMKH
            // 
            this.tbMKH.Location = new System.Drawing.Point(77, 143);
            this.tbMKH.Name = "tbMKH";
            this.tbMKH.Size = new System.Drawing.Size(128, 25);
            this.tbMKH.TabIndex = 1;
            // 
            // tbMV
            // 
            this.tbMV.Location = new System.Drawing.Point(77, 86);
            this.tbMV.Name = "tbMV";
            this.tbMV.Size = new System.Drawing.Size(128, 25);
            this.tbMV.TabIndex = 1;
            // 
            // tbMCB
            // 
            this.tbMCB.Location = new System.Drawing.Point(77, 29);
            this.tbMCB.Name = "tbMCB";
            this.tbMCB.Size = new System.Drawing.Size(128, 25);
            this.tbMCB.TabIndex = 1;
            // 
            // lb9
            // 
            this.lb9.AutoSize = true;
            this.lb9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb9.Location = new System.Drawing.Point(498, 143);
            this.lb9.Name = "lb9";
            this.lb9.Size = new System.Drawing.Size(52, 19);
            this.lb9.TabIndex = 0;
            this.lb9.Text = "Giá vé";
            // 
            // lb8
            // 
            this.lb8.AutoSize = true;
            this.lb8.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb8.Location = new System.Drawing.Point(498, 88);
            this.lb8.Name = "lb8";
            this.lb8.Size = new System.Drawing.Size(37, 19);
            this.lb8.TabIndex = 0;
            this.lb8.Text = "Ghế";
            // 
            // lb7
            // 
            this.lb7.AutoSize = true;
            this.lb7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb7.Location = new System.Drawing.Point(495, 31);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(58, 19);
            this.lb7.TabIndex = 0;
            this.lb7.Text = "SB đến";
            // 
            // lb5
            // 
            this.lb5.AutoSize = true;
            this.lb5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb5.Location = new System.Drawing.Point(244, 88);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(73, 19);
            this.lb5.TabIndex = 0;
            this.lb5.Text = "Ngày đến";
            // 
            // lb4
            // 
            this.lb4.AutoSize = true;
            this.lb4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb4.Location = new System.Drawing.Point(244, 31);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(62, 19);
            this.lb4.TabIndex = 0;
            this.lb4.Text = "Ngày đi";
            // 
            // lb6
            // 
            this.lb6.AutoSize = true;
            this.lb6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb6.Location = new System.Drawing.Point(244, 145);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(47, 19);
            this.lb6.TabIndex = 0;
            this.lb6.Text = "SB đi";
            // 
            // lb3
            // 
            this.lb3.AutoSize = true;
            this.lb3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb3.Location = new System.Drawing.Point(13, 145);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(51, 19);
            this.lb3.TabIndex = 0;
            this.lb3.Text = "Mã kh";
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb2.Location = new System.Drawing.Point(15, 88);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(50, 19);
            this.lb2.TabIndex = 0;
            this.lb2.Text = "Mã vé";
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1.Location = new System.Drawing.Point(15, 34);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(51, 19);
            this.lb1.TabIndex = 0;
            this.lb1.Text = "Mã cb";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(10, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(792, 252);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vé 1 chiều";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(18, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(753, 212);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btReturn
            // 
            this.btReturn.BackColor = System.Drawing.Color.SkyBlue;
            this.btReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btReturn.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btReturn.Image = global::LTwin_ChuyenBay.Properties.Resources.back;
            this.btReturn.Location = new System.Drawing.Point(1095, 164);
            this.btReturn.Name = "btReturn";
            this.btReturn.Size = new System.Drawing.Size(130, 59);
            this.btReturn.TabIndex = 8;
            this.btReturn.Text = "Quay về";
            this.btReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btReturn.UseVisualStyleBackColor = false;
            this.btReturn.Click += new System.EventHandler(this.btReturn_Click);
            // 
            // btSua
            // 
            this.btSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btSua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSua.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSua.Image = global::LTwin_ChuyenBay.Properties.Resources.edit;
            this.btSua.Location = new System.Drawing.Point(1095, 69);
            this.btSua.Name = "btSua";
            this.btSua.Size = new System.Drawing.Size(121, 59);
            this.btSua.TabIndex = 7;
            this.btSua.Text = "Sửa";
            this.btSua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btSua.UseVisualStyleBackColor = false;
            this.btSua.Click += new System.EventHandler(this.btSua_Click);
            // 
            // btXoa
            // 
            this.btXoa.BackColor = System.Drawing.Color.SkyBlue;
            this.btXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXoa.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa.Image = global::LTwin_ChuyenBay.Properties.Resources.bin;
            this.btXoa.Location = new System.Drawing.Point(880, 164);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(121, 59);
            this.btXoa.TabIndex = 6;
            this.btXoa.Text = "Xóa";
            this.btXoa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btXoa.UseVisualStyleBackColor = false;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);
            // 
            // btThem
            // 
            this.btThem.BackColor = System.Drawing.Color.SkyBlue;
            this.btThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThem.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem.Image = global::LTwin_ChuyenBay.Properties.Resources.add;
            this.btThem.Location = new System.Drawing.Point(880, 69);
            this.btThem.Name = "btThem";
            this.btThem.Size = new System.Drawing.Size(121, 59);
            this.btThem.TabIndex = 5;
            this.btThem.Text = "Thêm";
            this.btThem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btThem.UseVisualStyleBackColor = false;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox3.BackgroundImage")));
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox3.Controls.Add(this.btReturn);
            this.groupBox3.Controls.Add(this.btSua);
            this.groupBox3.Controls.Add(this.btXoa);
            this.groupBox3.Controls.Add(this.btThem);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1438, 559);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            // 
            // ve1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1439, 557);
            this.Controls.Add(this.groupBox3);
            this.Name = "ve1";
            this.Text = "ve1";
            this.Load += new System.EventHandler(this.ve1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbGV1;
        private System.Windows.Forms.TextBox tbGhe1;
        private System.Windows.Forms.DateTimePicker dtDI1;
        private System.Windows.Forms.TextBox tbSBden1;
        private System.Windows.Forms.DateTimePicker dtDEN1;
        private System.Windows.Forms.TextBox tbSB1;
        private System.Windows.Forms.TextBox tbMKH;
        private System.Windows.Forms.TextBox tbMV;
        private System.Windows.Forms.TextBox tbMCB;
        private System.Windows.Forms.Label lb9;
        private System.Windows.Forms.Label lb8;
        private System.Windows.Forms.Label lb7;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Label lb4;
        private System.Windows.Forms.Label lb6;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btThem;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btSua;
        private System.Windows.Forms.Button btReturn;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}