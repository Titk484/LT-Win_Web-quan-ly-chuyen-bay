﻿
namespace LTwin_ChuyenBay
{
    partial class Quanlychuyenbay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnGioithieu = new System.Windows.Forms.Button();
            this.btnQuanly = new System.Windows.Forms.Button();
            this.btnPhannan = new System.Windows.Forms.Button();
            this.btnChuyenbay = new System.Windows.Forms.Button();
            this.btnDatve = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCloseChildForm = new System.Windows.Forms.Button();
            this.panelTieude = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.lblTieude = new System.Windows.Forms.Label();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelTieude.SuspendLayout();
            this.panelDesktopPane.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelMenu.Controls.Add(this.btnGioithieu);
            this.panelMenu.Controls.Add(this.btnQuanly);
            this.panelMenu.Controls.Add(this.btnPhannan);
            this.panelMenu.Controls.Add(this.btnChuyenbay);
            this.panelMenu.Controls.Add(this.btnDatve);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(207, 856);
            this.panelMenu.TabIndex = 0;
            this.panelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMenu_Paint);
            // 
            // btnGioithieu
            // 
            this.btnGioithieu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGioithieu.FlatAppearance.BorderSize = 0;
            this.btnGioithieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGioithieu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGioithieu.ForeColor = System.Drawing.Color.SeaShell;
            this.btnGioithieu.Image = global::LTwin_ChuyenBay.Properties.Resources.send_mail;
            this.btnGioithieu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGioithieu.Location = new System.Drawing.Point(0, 320);
            this.btnGioithieu.Name = "btnGioithieu";
            this.btnGioithieu.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnGioithieu.Size = new System.Drawing.Size(207, 60);
            this.btnGioithieu.TabIndex = 5;
            this.btnGioithieu.Text = "Giới thiệu";
            this.btnGioithieu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnGioithieu.UseVisualStyleBackColor = false;
            this.btnGioithieu.Click += new System.EventHandler(this.btnGioithieu_Click);
            // 
            // btnQuanly
            // 
            this.btnQuanly.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQuanly.FlatAppearance.BorderSize = 0;
            this.btnQuanly.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanly.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanly.ForeColor = System.Drawing.Color.SeaShell;
            this.btnQuanly.Image = global::LTwin_ChuyenBay.Properties.Resources.content_management_system;
            this.btnQuanly.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanly.Location = new System.Drawing.Point(0, 260);
            this.btnQuanly.Name = "btnQuanly";
            this.btnQuanly.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnQuanly.Size = new System.Drawing.Size(207, 60);
            this.btnQuanly.TabIndex = 4;
            this.btnQuanly.Text = "Quản Lý";
            this.btnQuanly.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnQuanly.UseVisualStyleBackColor = false;
            this.btnQuanly.Click += new System.EventHandler(this.btnQuanly_Click);
            // 
            // btnPhannan
            // 
            this.btnPhannan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPhannan.FlatAppearance.BorderSize = 0;
            this.btnPhannan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPhannan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhannan.ForeColor = System.Drawing.Color.SeaShell;
            this.btnPhannan.Image = global::LTwin_ChuyenBay.Properties.Resources.review;
            this.btnPhannan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPhannan.Location = new System.Drawing.Point(0, 200);
            this.btnPhannan.Name = "btnPhannan";
            this.btnPhannan.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnPhannan.Size = new System.Drawing.Size(207, 60);
            this.btnPhannan.TabIndex = 3;
            this.btnPhannan.Text = "Đặt Vé";
            this.btnPhannan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPhannan.UseVisualStyleBackColor = false;
            this.btnPhannan.Click += new System.EventHandler(this.btnPhannan_Click);
            // 
            // btnChuyenbay
            // 
            this.btnChuyenbay.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnChuyenbay.FlatAppearance.BorderSize = 0;
            this.btnChuyenbay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChuyenbay.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChuyenbay.ForeColor = System.Drawing.Color.SeaShell;
            this.btnChuyenbay.Image = global::LTwin_ChuyenBay.Properties.Resources.airplane;
            this.btnChuyenbay.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChuyenbay.Location = new System.Drawing.Point(0, 140);
            this.btnChuyenbay.Name = "btnChuyenbay";
            this.btnChuyenbay.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnChuyenbay.Size = new System.Drawing.Size(207, 60);
            this.btnChuyenbay.TabIndex = 2;
            this.btnChuyenbay.Text = "DS Chuyến bay";
            this.btnChuyenbay.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnChuyenbay.UseVisualStyleBackColor = false;
            this.btnChuyenbay.Click += new System.EventHandler(this.btnChuyenbay_Click);
            // 
            // btnDatve
            // 
            this.btnDatve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnDatve.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDatve.FlatAppearance.BorderSize = 0;
            this.btnDatve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDatve.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatve.ForeColor = System.Drawing.Color.White;
            this.btnDatve.Image = global::LTwin_ChuyenBay.Properties.Resources.booking__1_;
            this.btnDatve.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDatve.Location = new System.Drawing.Point(0, 80);
            this.btnDatve.Name = "btnDatve";
            this.btnDatve.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnDatve.Size = new System.Drawing.Size(207, 60);
            this.btnDatve.TabIndex = 1;
            this.btnDatve.Text = "KT Vé";
            this.btnDatve.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDatve.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDatve.UseVisualStyleBackColor = false;
            this.btnDatve.Click += new System.EventHandler(this.btnDatve_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Controls.Add(this.btnCloseChildForm);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(207, 80);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LTwin_ChuyenBay.Properties.Resources.airplane__3_;
            this.pictureBox1.Location = new System.Drawing.Point(56, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 57);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnCloseChildForm
            // 
            this.btnCloseChildForm.FlatAppearance.BorderSize = 0;
            this.btnCloseChildForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseChildForm.Image = global::LTwin_ChuyenBay.Properties.Resources.esc;
            this.btnCloseChildForm.Location = new System.Drawing.Point(145, 49);
            this.btnCloseChildForm.Name = "btnCloseChildForm";
            this.btnCloseChildForm.Size = new System.Drawing.Size(85, 31);
            this.btnCloseChildForm.TabIndex = 0;
            this.btnCloseChildForm.UseVisualStyleBackColor = true;
            this.btnCloseChildForm.Click += new System.EventHandler(this.btnCloseChildForm_Click);
            // 
            // panelTieude
            // 
            this.panelTieude.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelTieude.Controls.Add(this.btnClose);
            this.panelTieude.Controls.Add(this.btnMaximize);
            this.panelTieude.Controls.Add(this.btnMinimize);
            this.panelTieude.Controls.Add(this.lblTieude);
            this.panelTieude.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTieude.Location = new System.Drawing.Point(207, 0);
            this.panelTieude.Name = "panelTieude";
            this.panelTieude.Size = new System.Drawing.Size(1573, 80);
            this.panelTieude.TabIndex = 1;
            this.panelTieude.Paint += new System.Windows.Forms.PaintEventHandler(this.panelTieude_Paint);
            this.panelTieude.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTieude_MouseDown);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = global::LTwin_ChuyenBay.Properties.Resources.button;
            this.btnClose.Location = new System.Drawing.Point(1516, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(57, 43);
            this.btnClose.TabIndex = 1;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.Image = global::LTwin_ChuyenBay.Properties.Resources.zoom;
            this.btnMaximize.Location = new System.Drawing.Point(1470, 6);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(50, 36);
            this.btnMaximize.TabIndex = 1;
            this.btnMaximize.UseVisualStyleBackColor = true;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Image = global::LTwin_ChuyenBay.Properties.Resources.zoom_out;
            this.btnMinimize.Location = new System.Drawing.Point(1423, 6);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(56, 36);
            this.btnMinimize.TabIndex = 1;
            this.btnMinimize.UseVisualStyleBackColor = true;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // lblTieude
            // 
            this.lblTieude.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTieude.AutoSize = true;
            this.lblTieude.Font = new System.Drawing.Font("Tahoma", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieude.ForeColor = System.Drawing.Color.White;
            this.lblTieude.Location = new System.Drawing.Point(446, 17);
            this.lblTieude.Name = "lblTieude";
            this.lblTieude.Size = new System.Drawing.Size(565, 28);
            this.lblTieude.TabIndex = 0;
            this.lblTieude.Text = "Chào mừng bạn đến với hãng hàng không WinX";
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.Controls.Add(this.pictureBox2);
            this.panelDesktopPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktopPane.Location = new System.Drawing.Point(207, 80);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(1573, 776);
            this.panelDesktopPane.TabIndex = 2;
            this.panelDesktopPane.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDesktopPane_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::LTwin_ChuyenBay.Properties.Resources.Stewardess_Woman_In_Uniform_With_Earth_And_Airplane;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1573, 800);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Quanlychuyenbay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1780, 856);
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelTieude);
            this.Controls.Add(this.panelMenu);
            this.Name = "Quanlychuyenbay";
            this.Text = "Quản lý chuyến bay";
            this.Load += new System.EventHandler(this.Quanlychuyenbay_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelTieude.ResumeLayout(false);
            this.panelTieude.PerformLayout();
            this.panelDesktopPane.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnDatve;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnGioithieu;
        private System.Windows.Forms.Button btnQuanly;
        private System.Windows.Forms.Button btnPhannan;
        private System.Windows.Forms.Button btnChuyenbay;
        private System.Windows.Forms.Panel panelTieude;
        private System.Windows.Forms.Label lblTieude;
        private System.Windows.Forms.Panel panelDesktopPane;
        private System.Windows.Forms.Button btnCloseChildForm;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

