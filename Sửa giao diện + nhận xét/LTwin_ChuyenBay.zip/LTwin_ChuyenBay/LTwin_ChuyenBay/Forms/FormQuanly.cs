﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LTwin_ChuyenBay.Forms
{
    public partial class FormQuanly : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-VDLUHCU\SQLEXPRESS;Initial Catalog=QLCB17;Integrated Security=True";

        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loadData1() //Ve
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from PHANCONG";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView2.DataSource = table;
        }

        public FormQuanly()
        {
            InitializeComponent();
        }

        private void btXem_Click(object sender, EventArgs e)
        {
            LinQDataContext db = new LinQDataContext();
            dataGridView1.DataSource = db.NHANVIENs.Select(q => q);
        }

        private void btXem2_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData1();

        }

        private void FormQuanly_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData1();


        }
    }
}
