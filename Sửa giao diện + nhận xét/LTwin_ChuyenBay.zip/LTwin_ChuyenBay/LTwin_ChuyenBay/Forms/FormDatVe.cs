﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LTwin_ChuyenBay.Forms
{
    public partial class FormDatVe : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-VDLUHCU\SQLEXPRESS;Initial Catalog=QLCB17;Integrated Security=True";

        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loadData()
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from DATVE";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }
        public FormDatVe()
        {
            InitializeComponent();
        }

        private void FormPhannan_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData();
        }

        private void btDatve_Click(object sender, EventArgs e)
        {
            string ktr = tbCMND.Text;
            int Countnum = 0; // đếm số lượng số trong CMND
            for (int i = 0; i < ktr.Length; i++)
            {
                if (ktr[i] >= '0' && ktr[i] <= '9') Countnum++;
            }

                command = connection.CreateCommand();
            if (tbGIOITINH.Text == "Nam"   || tbGIOITINH.Text == "Nu")
            {
                if(ktr.Length == 9)
                {
                    if(tbMCB.Text=="VN-012"|| tbMCB.Text == "VN-021" || tbMCB.Text == "VJ-458" || tbMCB.Text == "VJ-047" || tbMCB.Text == "QH-085" || tbMCB.Text == "QH-154" )
                    {
                        command.CommandText = "insert into DATVE values('" + tbTen.Text + "','" + tbCMND.Text + "','" + tbSDT.Text + "','" + tbGIOITINH.Text + "','" + tbGHEDACHON.Text + "','" + tbMCB.Text + "')";
                        command.ExecuteNonQuery();
                    }
                    else MessageBox.Show("Không hợp lệ, nhập lại MaCB !");

                }
                else MessageBox.Show("Không hợp lệ, nhập lại CMND !");
 
            }
            else MessageBox.Show("Không hợp lệ");
            //command.CommandText = "insert into DATVE values('" + tbTen.Text + "','" + tbCMND.Text + "','" + tbSDT.Text + "','" + tbGIOITINH.Text + "','" + tbGHEDACHON.Text + "','" + tbMCB.Text + "')";
            //command.ExecuteNonQuery();
            loadData();
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            tbMCB.ReadOnly = true;
            command = connection.CreateCommand();
            command.CommandText = "update DATVE set TEN = '" + tbTen.Text + "',CMND = '" + tbCMND.Text + "',SDT = '" + tbSDT.Text + "',GIOITINH = '" + tbGIOITINH.Text + "',GHEDACHON = '" + tbGHEDACHON.Text + "' where MACB = '" + tbMCB.Text + "'";
            command.ExecuteNonQuery();
            loadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            tbTen.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            tbCMND.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            tbSDT.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            tbGIOITINH.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            tbGHEDACHON.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
            tbMCB.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from DATVE where MACB = '" + tbMCB.Text + "'";
            command.ExecuteNonQuery();
            loadData();
        }

        private void btKhoiTao_Click(object sender, EventArgs e)
        {
            tbTen.Text = "";
            tbCMND.Text = "";
            tbSDT.Text = "";
            tbGIOITINH.Text = "";
            tbGHEDACHON.Text = "";
            tbMCB.Text = "";
        }
        /*string Username, Password;
            Username = txtUser.Text;
            Password = txtPass.Text;

            int Countnum = 0; // đếm số lượng số trong password
            int Countup = 0; // đếm số lượng chữ viết hoa trong password
            int Countlow = 0; // đếm số lượng chữ viết thường trong password
            int Countsp = 0; // đếm số lượng ký tự đặc biệt trong password

            for (int i = 0; i < Password.Length; i++)
            {
                if (Password[i] >= '0' && Password[i] <= '9') Countnum++;
                if (Password[i] >= 'a' && Password[i] <= 'z') Countlow++;
                if (Password[i] >= 'A' && Password[i] <= 'Z') Countup++;
                if (Password[i] >= '!' && Password[i] <= '/' ||
                    Password[i] >= ':' && Password[i] <= '@' ||
                    Password[i] >= '[' && Password[i] <= '`' ||
                    Password[i] >= '{' && Password[i] <= '~') Countsp++;
            }

            if (Username == "" && Password == "")
            {
                MessageBox.Show("User và pass không được trống.");
            }
            else if (Username == "")
            {
                MessageBox.Show("User không được trống");
            }
            else if (Password == "")
            {
                MessageBox.Show("Pass không được trống");
            }
            else if (Username.Length <= 8)
            {
                MessageBox.Show("Tên đăng nhập phải nhiều hơn 8 ký tự!!!");
            }
            else if (Countnum == 0)
            {
                MessageBox.Show("Mật khẩu thiếu số!");
            }
            else if (Countlow == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự thường!");
            }
            else if (Countup == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự HOA!");
            }
            else if (Countsp == 0)
            {
                MessageBox.Show("Mật khẩu thiếu ký tự đặc biệt!");
            }
            else
            {
                /*
                if (Username == "admin" && Password == "12345")
                {
                    MessageBox.Show("Đăng nhập thành công!");
                }
                
                if (txtUser.Text == "TuanKiet1" && txtPass.Text == "Kk462020!")
                {
                    this.Hide();
        Controller obj = new Controller();
        obj.User = "TuanKiet1";
                    obj.Pass = "Kk462020!";

                    Thongbao f = new Thongbao(obj);
        f.Show();
                }

                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu sai, xin vui lòng nhập lại");
                }
            }
         
         */
    }
}
