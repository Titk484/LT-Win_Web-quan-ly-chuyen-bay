﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LTwin_ChuyenBay.Forms
{
    public partial class FormDSChuyenbay : Form
    {
        public FormDSChuyenbay()
        {
            InitializeComponent();
        }

        private void btXem_Click(object sender, EventArgs e)
        {
            LinQDataContext db = new LinQDataContext();
            dataGridView1.DataSource = db.CHUYENBAYs.Select(q => q);
        }

        private void btTH_Click(object sender, EventArgs e)
        {
            if (cbMCB.Text == null || cbMCB.Text == "") MessageBox.Show("Chọn lại mã chuyến bay");
            else if (cbMCB.Text != null)
            {
                if (cbMCB.Text == "VN-012" || cbMCB.Text == "VN-021")
                {
                    CB_VN n = new CB_VN();
                    n.Show();
                }
                else if (cbMCB.Text == "VJ-458" || cbMCB.Text == "VJ-047")
                {
                    CB_VJ m = new CB_VJ();
                    m.Show();
                }
                else if (cbMCB.Text == "QH-085" || cbMCB.Text == "QH-154")
                {
                    CB_QH p = new CB_QH();
                    p.Show();
                }

            }   
        }

        private void FormDSChuyenbay_Load(object sender, EventArgs e)
        {

        }
    }
}
