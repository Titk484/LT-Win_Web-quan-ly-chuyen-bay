﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LTwin_ChuyenBay.Forms
{
    public partial class FormKTve : Form
    {

        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-VDLUHCU\SQLEXPRESS;Initial Catalog=QLCB17;Integrated Security=True";

        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

       /* void loadData1()
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from VE";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }
        void loadData2()
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from VE2Chieu";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }*/
        public FormKTve()
        {
            InitializeComponent();
        }
        
       private void cbVe_SelectedIndexChanged(object sender, EventArgs e)
        {
           


        }
       
  

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
               

        }

        private void btXem_Click(object sender, EventArgs e)
        {
            if (cbVe.Text == "Vé 1 chiều")
            {
                ve1 n = new ve1();
                n.Show();
            }
            else if (cbVe.Text == "Vé 2 chiều")
            {
                ve2 m = new ve2();
                m.Show();
            }
            else MessageBox.Show("Chọn lại loại vé !");
        }

        private void btSua_Click(object sender, EventArgs e)
        {
           
        }

        private void btThem_Click(object sender, EventArgs e)
        {   
            
        }

        private void FormDatve_Load(object sender, EventArgs e)
        {
            
            
        }

        private void btXem_Click_1(object sender, EventArgs e)
        {
            if (cbVe.Text == "Vé 1 chiều")
            {
                ve1 n = new ve1();
                n.Show();
            }
            else if (cbVe.Text == "Vé 2 chiều")
            {
                ve2 m = new ve2();
                m.Show();
            }
            else MessageBox.Show("Chọn lại loại vé !");
        }
    }
}

