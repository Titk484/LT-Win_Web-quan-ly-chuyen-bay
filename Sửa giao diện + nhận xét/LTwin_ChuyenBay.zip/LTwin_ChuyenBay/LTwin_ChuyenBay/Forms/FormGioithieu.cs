﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LTwin_ChuyenBay.Forms
{
    public partial class FormGioithieu : Form
    {
        public FormGioithieu()
        {
            InitializeComponent();
        }



        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormGioithieu_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string MaMB = listBox1.SelectedItem.ToString();
            switch (MaMB)
            {
                case "Vietnam Airlines":
                    listBox2.Items.Clear();
                    listBox2.Items.Add("Hãng Hàng không Quốc gia Việt Nam (Vietnam Airlines) chính thức hình thành");
                    listBox2.Items.Add("vào tháng 4/1933 với tư cách là một đơn vị kinh doanh vận tải hàng không có");
                    listBox2.Items.Add("quy mô lớn của Nhà nước. Vào ngày 27 / 05 / 1995, Tổng Công ty Hàng không");
                    listBox2.Items.Add("Việt Nam được thành lập trên cơ sở liên kết 20 doanh nghiệp hoạt động kinh");
                    listBox2.Items.Add("doanh dịch vụ hàng không, lấy Vietnam Airlines làm nòng cốt.");
                    break;
                case "Vietjet Air":
                    listBox2.Items.Clear();
                    listBox2.Items.Add("Vietjet Air là hãng hàng không tư nhân đầu tiên tham gia thị trường vận tải");
                    listBox2.Items.Add("hàng không tại Việt Nam, được cấp giấy phép hoạt động từ tháng 12 năm 2007.");
                    listBox2.Items.Add("Được thành lập từ 3 cổ đông chính là Tập đoàn T & C, Sovico Holdings và");
                    listBox2.Items.Add("Ngân hàng Thương mại Cổ phần Phát triển Nhà TP Hồ Chí Minh(HD Bank).");
                    break;
                case "Bamboo Airways":
                    listBox2.Items.Clear();

                    listBox2.Items.Add("Từ niềm tự hào dân tộc cùng nguồn cảm hứng trên hành trình khai phá,");
                    listBox2.Items.Add("Bamboo Airways – một thành viên của Tập đoàn FLC – chính thức ra đời vào");
                    listBox2.Items.Add("năm 2017. Song song với các thỏa thuận hợp tác và đầu tư lớn là những định ");
                    listBox2.Items.Add("hướng rõ ràng cho việc phát triển thương hiệu.Bộ nhận diện thương hiệu");
                    listBox2.Items.Add("với biểu tượng Tre Việt đầy sức sống được cách điệu và phát triển bởi tập");
                    listBox2.Items.Add("đoàn LIFT Strategic Design – nhà thiết kế thương hiệu lừng danh thế giới.");
                    break;
            }

            string pic = listBox1.SelectedItem.ToString();
            switch (pic)
            {
                case "Vietnam Airlines":
                    pictureBox1.Image = new Bitmap(@"D:\Cuối kỳ LT win\chỉnh nộp thầy\1\21-12\tétt giới thiệu\LTwin_ChuyenBay_xonggiaodien\LTwin_ChuyenBay\LTwin_ChuyenBay\Picture\mbVN.png");
                    break;
                case "Vietjet Air":
                    pictureBox1.Image = new Bitmap(@"D:\Cuối kỳ LT win\chỉnh nộp thầy\1\21-12\tétt giới thiệu\LTwin_ChuyenBay_xonggiaodien\LTwin_ChuyenBay\LTwin_ChuyenBay\Picture\mbVJ.jpg");
                    break;
                case "Bamboo Airways":
                    pictureBox1.Image = new Bitmap(@"D:\Cuối kỳ LT win\chỉnh nộp thầy\1\21-12\tétt giới thiệu\LTwin_ChuyenBay_xonggiaodien\LTwin_ChuyenBay\LTwin_ChuyenBay\Picture\mbBB.png");
                    break;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text == "Vietnam Airlines")
            {
                listBox3.Items.Clear();
                listBox3.Items.Add("Bành Văn Khoa: Dùng vé phổ thông đi chuyến bay từ HCM ra Hà Nội, máy bay rất êm ái, nhân viên ân cần, care khách");
                listBox3.Items.Add("hàng nhiều !! Good Good, like like.");
                listBox3.Items.Add("");
                listBox3.Items.Add("Lê Hoàng Việt Tuấn: Dịch vụ của toàn chuyến bay ổn, trang trí thêm về background đặt vé của hãng, trông hơi đơn");
                listBox3.Items.Add("sơ và không có sức hút.");
                listBox3.Items.Add("");
                listBox3.Items.Add("Nguyễn Thị Tuấn Kiệt: Nhân viên phục vụ nhiệt tình, ghế ngồi giữa 2 hàng còn hẹp không thoải mái.");
                listBox3.Items.Add("");
                listBox3.Items.Add("...");

            } 
            else if (comboBox1.Text == "Vietjet Air")
            {
                listBox3.Items.Clear();
                listBox3.Items.Add("Nguyễn Việt Thắng: Tôi đi cùng bà, bà lớn tuổi nên đi lại có chút khó khăn, nên tui cũng có chút lo ngại, nhưng các");
                listBox3.Items.Add("bạn nhân viên đã rất nhiệt tình, họ hỗ trợ bà tôi và vẫn vô cùng tỉ mỉ khi hỏi thăm ý kiến hành khách, xin phép được");
                listBox3.Items.Add("giúp đỡ bà tôi trước và mong hành khách khác thông cảm giúp chúng tôi.");
                listBox3.Items.Add("");
                listBox3.Items.Add("Nguyễn Dương Nghĩa: Khâu chăm sóc KH của hãng rất tốt, khiến tôi hài lòng.");
                listBox3.Items.Add("");
                listBox3.Items.Add("Lê Anh Chí: Các thức ăn trên menu hầu như không có và giá mắc hơn rất nhiều so với thị trường.");
                listBox3.Items.Add("");
                listBox3.Items.Add("...");
            }
            else if (comboBox1.Text == "Bamboo Airways")
            {
                listBox3.Items.Clear();
                listBox3.Items.Add("Đỗ Hoa Hậu: Máy bay có màu sắc bắt mắt-sang trọng, nhân viên tươi cười niềm nở, chuyến bay tạo được");
                listBox3.Items.Add("cảm giác an toàn.");
                listBox3.Items.Add("");
                listBox3.Items.Add("Andree Waston: It is so good, I feel interesting !! Yup");
                listBox3.Items.Add("");
                listBox3.Items.Add("Hoàng Trung: Tôi cảm thấy được sự ân cần và chu đáo của cả hãng máy bay dành cho khách hàng, nhiệt huyết");
                listBox3.Items.Add("trong công cuộc chăm sóc khách hàng !!");
                listBox3.Items.Add("");
                listBox3.Items.Add("...");
            }
        }
    }
}
